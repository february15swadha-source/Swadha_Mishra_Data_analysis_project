AIR POLLUTION ANALYSIS PROJECT

Used Data is from Official Indian data portals:
https://www.data.gov.in/
https://cpcb.nic.in/

Use Analysis features are
1) View air pollution data 
2) Calculate average AQI
3)Compare pollution levels between cities
4)Analysis diffrent pollutants
5)Identify the most polluted cities
6) Study pollution treands
7)generate graphs 


