from pathlib import Path
from datetime import datetime


def generate_summary_report(data, title):
    """Write a text summary report using Python file handling."""
    output_folder = Path("output")
    output_folder.mkdir(exist_ok=True)

    report_file = output_folder / "air_pollution_summary_report.txt"

    with open(report_file, "w", encoding="utf-8") as file:
        file.write("AIR POLLUTION ANALYSIS PROJECT\n")
        file.write("=" * 45 + "\n")
        file.write("Report type: " + title + "\n")
        file.write("Generated on: " + datetime.now().strftime("%d-%m-%Y %H:%M:%S") + "\n\n")

        file.write("DATASET INFORMATION\n")
        file.write("-" * 30 + "\n")
        file.write("Total records: " + str(len(data)) + "\n")
        file.write("Total columns: " + str(len(data.columns)) + "\n")
        file.write("Column names: " + ", ".join(map(str, data.columns)) + "\n\n")

        file.write("MISSING VALUE INFORMATION\n")
        file.write("-" * 30 + "\n")
        file.write(data.isnull().sum().to_string())
        file.write("\n\nSTATISTICAL SUMMARY\n")
        file.write("-" * 30 + "\n")
        file.write(data.describe(include="all").to_string())

        file.write("\n\nOriginal source data has not been modified.\n")
        file.write("Record management changes are stored in a separate working CSV.\n")

    print("\nSummary report generated:", report_file)
