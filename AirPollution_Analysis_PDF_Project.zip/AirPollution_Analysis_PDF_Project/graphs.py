from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

# This file runs independently. It does not change main.py or your CSV.
DATA_FILE = Path("data/historical_air_quality.csv")

def find_column(data, possible_names):
    """Find a column while ignoring capitalization and extra spaces."""
    lookup = {str(col).strip().lower(): col for col in data.columns}
    for name in possible_names:
        found = lookup.get(name.strip().lower())
        if found is not None:
            return found
    return None

def numeric_values(data, column):
    """Convert a temporary plotting series to numbers; original CSV stays unchanged."""
    return pd.to_numeric(data[column], errors="coerce")

def choose_pollutant(data):
    options = [
        ("PM 2.5", find_column(data, ["PM 2.5", "PM2.5"])),
        ("RSPM/PM10", find_column(data, ["RSPM/PM10", "RSPM", "PM10"])),
        ("NO2", find_column(data, ["NO2"])),
        ("SO2", find_column(data, ["SO2"])),
    ]
    for label, column in options:
        if column is not None and numeric_values(data, column).notna().any():
            return label, column
    return None, None

def pollution_trend(data):
    date_col = find_column(data, ["Sampling Date", "sampling_date", "Date"])
    label, pollutant_col = choose_pollutant(data)
    if date_col is None or pollutant_col is None:
        print("Trend graph unavailable: date or numeric pollutant column not found.")
        return

    dates = pd.to_datetime(data[date_col], errors="coerce", dayfirst=True)
    values = numeric_values(data, pollutant_col)
    temporary = pd.DataFrame({"date": dates, "value": values})
    temporary = temporary.loc[temporary["date"].notna() & temporary["value"].notna()]
    if temporary.empty:
        print("No usable date and pollutant values are available for this graph.")
        return

    trend = temporary.groupby("date")["value"].mean().sort_index()
    plt.figure(figsize=(10, 5))
    plt.plot(trend.index, trend.values, marker="o")
    plt.title(f"{label} Pollution Trend Over Time")
    plt.xlabel("Sampling date")
    plt.ylabel(f"Average {label}")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

def city_comparison(data):
    city_col = find_column(data, ["City/Town/Village/Area", "City", "Location"])
    label, pollutant_col = choose_pollutant(data)
    if city_col is None or pollutant_col is None:
        print("City comparison unavailable: city or numeric pollutant column not found.")
        return

    temporary = pd.DataFrame({
        "city": data[city_col].astype("string"),
        "value": numeric_values(data, pollutant_col)
    })
    temporary = temporary.loc[temporary["city"].notna() & temporary["value"].notna()]
    if temporary.empty:
        print("No usable city and pollutant values are available for this graph.")
        return

    comparison = temporary.groupby("city")["value"].mean().sort_values(ascending=False).head(10)
    plt.figure(figsize=(10, 5))
    comparison.sort_values().plot(kind="barh")
    plt.title(f"Top 10 Locations by Average {label}")
    plt.xlabel(f"Average {label}")
    plt.ylabel("City / location")
    plt.tight_layout()
    plt.show()

def pollutant_comparison(data):
    pollutant_columns = []
    for name, candidates in [
        ("SO2", ["SO2"]),
        ("NO2", ["NO2"]),
        ("RSPM/PM10", ["RSPM/PM10", "RSPM", "PM10"]),
        ("PM 2.5", ["PM 2.5", "PM2.5"]),
    ]:
        column = find_column(data, candidates)
        if column is not None:
            values = numeric_values(data, column)
            if values.notna().any():
                pollutant_columns.append((name, values.mean()))

    if not pollutant_columns:
        print("No numeric pollutant columns were found.")
        return

    names = [item[0] for item in pollutant_columns]
    averages = [item[1] for item in pollutant_columns]
    plt.figure(figsize=(8, 5))
    plt.bar(names, averages)
    plt.title("Average Pollutant Comparison")
    plt.xlabel("Pollutant")
    plt.ylabel("Average recorded value")
    plt.tight_layout()
    plt.show()

def pollution_distribution(data):
    label, pollutant_col = choose_pollutant(data)
    if pollutant_col is None:
        print("Distribution graph unavailable: no numeric pollutant column found.")
        return

    values = numeric_values(data, pollutant_col).dropna()
    if values.empty:
        print("No numeric readings are available for this graph.")
        return

    plt.figure(figsize=(8, 5))
    plt.hist(values, bins=20, edgecolor="black")
    plt.title(f"Distribution of {label} Readings")
    plt.xlabel(f"{label} reading")
    plt.ylabel("Number of records")
    plt.tight_layout()
    plt.show()

def main():
    if not DATA_FILE.exists():
        print(f"CSV file not found: {DATA_FILE}")
        print("Put historical_air_quality.csv inside the project's data folder.")
        return

    try:
        data = pd.read_csv(DATA_FILE)
    except Exception as error:
        print("Could not read the CSV:", error)
        return

    print("\n========== AIR ANALYSIS GRAPH  ==========")
    print("1. Pollution trend over time")
    print("2. City-wise pollution comparison")
    print("3. Pollutant comparison")
    print("4. Pollution reading distribution")
    print("5. Show all four graphs")
    print("6. Exit")

    while True:
        choice = input("\nEnter your choice: ").strip()
        if choice == "1":
            pollution_trend(data)
        elif choice == "2":
            city_comparison(data)
        elif choice == "3":
            pollutant_comparison(data)
        elif choice == "4":
            pollution_distribution(data)
        elif choice == "5":
            pollution_trend(data)
            city_comparison(data)
            pollutant_comparison(data)
            pollution_distribution(data)
        elif choice == "6":
            print("Exiting graph menu.")
            break
        else:
            print("Please enter a number from 1 to 6.")

if __name__ == "__main__":
    main()
