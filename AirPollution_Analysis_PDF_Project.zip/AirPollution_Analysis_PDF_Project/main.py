from pathlib import Path

from data_operations import (
    load_csv, create_working_copy, load_working_copy,
    display_records, search_record, add_record, update_record, delete_record
)
from analysis import (
    show_pandas_analysis, show_numpy_analysis,
    show_missing_values, show_data_structures
)
from report import generate_summary_report

HISTORICAL_FILE = Path("data/historical_air_quality.csv")
WORKING_FILE = Path("data/airvision_records.csv")


def run_analysis(data, title):
    if data is None:
        print("Dataset is not available.")
        return

    print("\n" + "=" * 55)
    print(title)
    print("=" * 55)

    show_missing_values(data)
    show_pandas_analysis(data)
    show_numpy_analysis(data)
    show_data_structures(data)
    generate_summary_report(data, title)


def record_menu():
    if not create_working_copy(HISTORICAL_FILE, WORKING_FILE):
        return

    data = load_working_copy(WORKING_FILE)

    while True:
        print("\n========== RECORD MANAGEMENT ==========")
        print("1. Add a new record")
        print("2. Display all records")
        print("3. Search for a record")
        print("4. Update an existing record")
        print("5. Delete a record")
        print("6. Return to main menu")

        choice = input("Enter your choice: ").strip()

        if choice == "1":
            result = add_record(data, WORKING_FILE)
            if result is not None:
                data = result
        elif choice == "2":
            display_records(data)
        elif choice == "3":
            search_record(data)
        elif choice == "4":
            result = update_record(data, WORKING_FILE)
            if result is not None:
                data = result
        elif choice == "5":
            result = delete_record(data, WORKING_FILE)
            if result is not None:
                data = result
        elif choice == "6":
            break
        else:
            print("Please enter a number from 1 to 6.")


def main():
    Path("data").mkdir(exist_ok=True)
    Path("output").mkdir(exist_ok=True)

    print("=" * 60)
    print("       AIR POLLUTION ANALYSIS SYSTEM")
    print("=" * 60)

    historical_data = load_csv(HISTORICAL_FILE)

    if historical_data is not None:
        print("\nDataset record count:", len(historical_data))
        if len(historical_data) < 50:
            print("WARNING: The assignment requires at least 50 records.")
            print("Please download a larger original dataset.")
        else:
            print("Minimum 50-record requirement: satisfied.")

    while True:
        print("\n=============== MAIN MENU ===============")
        print("1. Analyse original air pollution dataset")
        print("2. Display all original records")
        print("3. Add / Search / Update / Delete records")
        print("4. Exit")

        choice = input("Enter your choice: ").strip()

        if choice == "1":
            run_analysis(historical_data, "Historical Air Pollution Analysis")
        elif choice == "2":
            display_records(historical_data)
        elif choice == "3":
            record_menu()
        elif choice == "4":
            print("Thank you for using the Air Pollution Analysis System.")
            break
        else:
            print("Invalid choice. Try again.")


if __name__ == "__main__":
    main()
