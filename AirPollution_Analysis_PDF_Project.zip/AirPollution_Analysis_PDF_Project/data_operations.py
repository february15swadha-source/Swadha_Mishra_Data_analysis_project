from pathlib import Path
import shutil
import pandas as pd


def load_csv(file_path):
    """Read the original CSV file into a Pandas DataFrame."""
    file_path = Path(file_path)

    if not file_path.exists():
        print("\nCSV file not found:", file_path)
        return None

    try:
        data = pd.read_csv(file_path)
        print("\nDataset loaded successfully.")
        print("File:", file_path)
        print("Number of records:", len(data))
        print("Number of columns:", len(data.columns))
        return data
    except Exception as error:
        print("Error while reading CSV:", error)
        return None


def create_working_copy(original_file, working_file):
    """Create a separate file for add/update/delete operations."""
    original_file = Path(original_file)
    working_file = Path(working_file)

    if not original_file.exists():
        print("First place the original historical CSV in the data folder.")
        return False

    if not working_file.exists():
        shutil.copy2(original_file, working_file)
        print("A separate record-management copy has been created.")
    else:
        print("Using the existing record-management copy.")

    return True


def load_working_copy(file_path):
    return load_csv(file_path)


def display_records(data):
    if data is None:
        print("No dataset available.")
        return

    print("\nALL RECORDS")
    print(data.to_string(index=True))


def search_record(data):
    if data is None or data.empty:
        print("No records available.")
        return

    print("Available columns:", list(data.columns))
    column = input("Enter the column name to search: ").strip()

    if column not in data.columns:
        print("Column not found.")
        return

    value = input("Enter the value or text to search: ").strip()

    found = data[column].astype(str).str.contains(
        value, case=False, regex=False, na=False
    )
    result = data.loc[found]

    if result.empty:
        print("No matching record found.")
    else:
        print("\nSEARCH RESULT")
        print(result.to_string(index=True))


def add_record(data, file_path):
    if data is None:
        print("No dataset available.")
        return None

    print("\nEnter values for the new record.")
    print("Use the same columns as the existing dataset.")
    new_record = {}

    for column in data.columns:
        new_record[column] = input(f"{column}: ")

    new_row = pd.DataFrame([new_record], columns=data.columns)
    updated_data = pd.concat([data, new_row], ignore_index=True)
    updated_data.to_csv(file_path, index=False)

    print("New record added to the working copy.")
    return updated_data


def update_record(data, file_path):
    if data is None or data.empty:
        print("No records available.")
        return None

    display_records(data)

    try:
        row_number = int(input("Enter the row index to update: "))
        if row_number not in data.index:
            print("Invalid row index.")
            return None
    except ValueError:
        print("Please enter a valid number.")
        return None

    print("Available columns:", list(data.columns))
    column = input("Enter the column name to update: ").strip()

    if column not in data.columns:
        print("Column not found.")
        return None

    new_value = input("Enter the new value: ")

    updated_data = data.copy()
    updated_data.at[row_number, column] = new_value
    updated_data.to_csv(file_path, index=False)

    print("Record updated in the working copy.")
    return updated_data


def delete_record(data, file_path):
    if data is None or data.empty:
        print("No records available.")
        return None

    display_records(data)

    try:
        row_number = int(input("Enter the row index to delete: "))
        if row_number not in data.index:
            print("Invalid row index.")
            return None
    except ValueError:
        print("Please enter a valid number.")
        return None

    confirm = input("Confirm deletion from working copy (yes/no): ").lower()

    if confirm != "yes":
        print("Deletion cancelled.")
        return None

    updated_data = data.drop(index=row_number).reset_index(drop=True)
    updated_data.to_csv(file_path, index=False)

    print("Record deleted from the working copy.")
    return updated_data
