import numpy as np
import pandas as pd


def show_missing_values(data):
    """Identify and display missing values without changing the dataset."""
    print("\n========== MISSING VALUE REPORT ==========")
    missing_values = data.isnull().sum()
    print(missing_values.to_string())
    print("Total missing cells:", int(missing_values.sum()))
    print("No missing values have been filled or deleted.")


def show_pandas_analysis(data):
    print("\n========== PANDAS ANALYSIS ==========")

    print("\n1. DataFrame:")
    print(data.head())

    print("\n2. Selected rows (first five):")
    print(data.iloc[0:5])

    print("\n3. Selected columns:")
    print(data.iloc[:, 0:min(5, len(data.columns))])

    print("\n4. Statistical analysis:")
    print(data.describe(include="all").to_string())

    # Select a numeric column for filtering and sorting.
    numeric_columns = data.select_dtypes(include="number").columns.tolist()

    if numeric_columns:
        column = numeric_columns[0]

        print(f"\n5. Filtering records where {column} is greater than its mean:")
        average = data[column].mean()
        filtered_data = data[data[column] > average]
        print(filtered_data.head(10).to_string(index=False))

        print(f"\n6. Sorting records by {column} in descending order:")
        sorted_data = data.sort_values(by=column, ascending=False)
        print(sorted_data.head(10).to_string(index=False))
    else:
        print("\nNo numeric columns were detected for numeric filtering/sorting.")

    # GroupBy using a likely location column.
    possible_location_columns = ["city", "location", "station", "state"]
    location_column = None

    for column in data.columns:
        if str(column).strip().lower() in possible_location_columns:
            location_column = column
            break

    if location_column and numeric_columns:
        value_column = numeric_columns[0]
        print(f"\n7. GroupBy: average {value_column} by {location_column}")
        grouped = data.groupby(location_column)[value_column].mean()
        print(grouped.to_string())
    else:
        print("\nGroupBy requires a location column and a numeric column.")
        print("Available columns:", list(data.columns))


def show_numpy_analysis(data):
    print("\n========== NUMPY IMPLEMENTATION ==========")

    numeric_data = data.select_dtypes(include="number")

    if numeric_data.empty:
        print("No numeric columns available for NumPy calculations.")
        return

    # 2D array
    array_2d = numeric_data.to_numpy(dtype=float)

    # 1D array using the first numeric column
    array_1d = array_2d[:, 0]

    print("\n1D Array:")
    print(array_1d)

    print("\n2D Array:")
    print(array_2d)

    print("\nArray indexing:")
    print("First value:", array_1d[0])
    print("First row of 2D array:", array_2d[0])

    print("\nArray slicing:")
    print("First five values:", array_1d[0:5])
    print("First five rows of 2D array:")
    print(array_2d[0:5, :])

    # NaN-aware statistics: missing values are not replaced in the source data.
    print("\nNumPy calculations on first numeric column:")
    print("Sum:", np.nansum(array_1d))
    print("Mean:", np.nanmean(array_1d))
    print("Maximum:", np.nanmax(array_1d))
    print("Minimum:", np.nanmin(array_1d))
    print("Standard deviation:", np.nanstd(array_1d))


def show_data_structures(data):
    print("\n========== PYTHON DATA STRUCTURES ==========")

    # 1. List and list methods
    pollutant_list = ["AQI", "SO2", "NO2", "RSPM", "SPM"]
    pollutant_list.append("PM2.5")
    print("\n1. List:", pollutant_list)
    print("List after append():", pollutant_list)

    # 2. Tuple
    dataset_columns = tuple(data.columns)
    print("\n2. Tuple of dataset columns:", dataset_columns)

    # 3. Set
    if len(data.columns) > 0:
        first_column_values = set(data.iloc[:, 0].astype(str))
        print("\n3. Set of unique values from first column:")
        print(first_column_values)

    # 4. Dictionary
    dataset_information = {
        "project_name": "Air Pollution Analysis",
        "number_of_records": len(data),
        "number_of_columns": len(data.columns)
    }
    print("\n4. Dictionary:", dataset_information)

    # 5. Dictionary methods
    dataset_information.update({"analysis_library": "Pandas and NumPy"})
    print("\n5. Dictionary get():", dataset_information.get("project_name"))
    print("Dictionary keys():", list(dataset_information.keys()))
    print("Dictionary values():", list(dataset_information.values()))
